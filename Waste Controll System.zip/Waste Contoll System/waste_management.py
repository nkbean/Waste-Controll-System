"""
Waste Collection Management System
Tkinter desktop app + PostgreSQL, with login and roles (admin / staff).
Drivers are records (no login); office staff enter collections for them.

Run:  py waste_management.py
First login:  admin / admin123  (change it right away with "Change Password")
"""
import datetime
import hashlib
import hmac
import os
import sys
import tkinter as tk
from decimal import Decimal, InvalidOperation
from tkinter import ttk, messagebox

import psycopg2
from psycopg2 import errors, sql as pgsql

# ---------------------------------------------------------------------------
# Database settings
# On other computers, change "host" to the server PC's IP (e.g. "192.168.1.10")
# ---------------------------------------------------------------------------
DB_CONFIG = {
    "host": "localhost",
    "port": 5432,
    "dbname": "waste_db",
    "user": "postgres",
    "password": "password",
}

WASTE_TYPES = ["general", "organic", "recyclable", "hazardous", "e-waste", "construction"]
COLLECTION_STATUS = ["collected", "pending", "missed"]
COMPLAINT_STATUS = ["open", "in_progress", "resolved"]
VEHICLE_STATUS = ["active", "maintenance", "inactive"]
ROLES = ["admin", "staff"]

# Logo: put an image named logo.png (or logo.jpg) in the same folder as this file.
APP_DIR = os.path.dirname(os.path.abspath(sys.argv[0]))
LOGO_FILES = [os.path.join(APP_DIR, name) for name in ("logo.png", "logo.jpg", "logo.jpeg")]
LOGO_SIZE = 160  # max width/height on the login screen, in pixels
# Login background: put background.jpg (or .png) in the same folder. It is stretched to fill the window.
BACKGROUND_FILES = [os.path.join(APP_DIR, name)
                    for name in ("background.jpg", "background.jpeg", "background.png")]

# ---------------------------------------------------------------------------
# Image helper
# ---------------------------------------------------------------------------
def load_logo(max_size):
    """Load the first logo file found, scaled to fit max_size. Returns None if there is none."""
    path = next((p for p in LOGO_FILES if os.path.exists(p)), None)
    if path is None:
        return None
    try:
        from PIL import Image, ImageTk  # Pillow: any format, smooth resizing
        image = Image.open(path)
        image.thumbnail((max_size, max_size))
        return ImageTk.PhotoImage(image)
    except ImportError:
        if not path.lower().endswith(".png"):
            return None  # without Pillow, Tkinter can only read PNG/GIF
        try:
            image = tk.PhotoImage(file=path)
        except tk.TclError:
            return None
        factor = max(1, -(-max(image.width(), image.height()) // max_size))
        return image.subsample(factor, factor)
    except Exception:
        return None

class BackgroundImage:
    """Fills its parent with the background picture and keeps it sized to the window."""

    def __init__(self, parent):
        self.parent = parent
        self.photo = None      # Tkinter needs a reference, or the picture disappears
        self.source = None     # original picture (Pillow), resized on every window resize
        self.pending = None
        path = next((p for p in BACKGROUND_FILES if os.path.exists(p)), None)
        if path is None:
            return

        self.label = tk.Label(parent, bd=0, highlightthickness=0)
        self.label.place(x=0, y=0, relwidth=1, relheight=1)
        self.label.lower()
        try:
            from PIL import Image
            self.source = Image.open(path).convert("RGB")
            parent.bind("<Configure>", self.schedule_resize, add="+")
        except ImportError:
            # Without Pillow: PNG only, shown at its original size
            if path.lower().endswith(".png"):
                try:
                    self.photo = tk.PhotoImage(file=path)
                    self.label.config(image=self.photo)
                except tk.TclError:
                    pass
        except Exception:
            pass

    def schedule_resize(self, event=None):
        # wait until the user stops resizing, so it stays smooth
        if self.pending:
            self.parent.after_cancel(self.pending)
        self.pending = self.parent.after(80, self.resize)

    def resize(self):
        self.pending = None
        try:
            from PIL import ImageOps, ImageTk
            width, height = self.parent.winfo_width(), self.parent.winfo_height()
            if width < 2 or height < 2:
                return
            # "cover": fill the whole window, cropping the edges if the shape doesn't match
            self.photo = ImageTk.PhotoImage(ImageOps.fit(self.source, (width, height)))
            self.label.config(image=self.photo)
        except tk.TclError:
            pass  # window was closed while resizing

# ---------------------------------------------------------------------------
# Database helpers
# ---------------------------------------------------------------------------
def run_query(query, params=None, fetch=None):
    """Run one query in its own connection. fetch: None, 'one' or 'all'."""
    conn = psycopg2.connect(**DB_CONFIG)
    try:
        with conn:
            with conn.cursor() as cur:
                cur.execute(query, params or None)
                if fetch == "one":
                    return cur.fetchone()
                if fetch == "all":
                    return cur.fetchall()
    finally:
        conn.close()


def hash_password(password):
    salt = os.urandom(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 200_000)
    return f"{salt.hex()}${digest.hex()}"


def verify_password(password, stored):
    try:
        salt_hex, hash_hex = stored.split("$")
    except (ValueError, AttributeError):
        return False
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt_hex), 200_000)
    return hmac.compare_digest(digest.hex(), hash_hex)


def ensure_database():
    """Create the database itself if it doesn't exist (needs a superuser)."""
    conn = psycopg2.connect(**{**DB_CONFIG, "dbname": "postgres"})
    conn.autocommit = True
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT 1 FROM pg_database WHERE datname = %s", (DB_CONFIG["dbname"],))
            if not cur.fetchone():
                cur.execute(pgsql.SQL("CREATE DATABASE {}").format(pgsql.Identifier(DB_CONFIG["dbname"])))
    finally:
        conn.close()


SCHEMA_SQL = """
    CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        username VARCHAR(50) UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        full_name VARCHAR(120) NOT NULL,
        phone VARCHAR(30),
        role VARCHAR(10) NOT NULL CHECK (role IN ('admin', 'staff')),
        is_active BOOLEAN NOT NULL DEFAULT TRUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS areas (
        id SERIAL PRIMARY KEY,
        name VARCHAR(100) UNIQUE NOT NULL,
        ward VARCHAR(50),
        description TEXT
    );
    CREATE TABLE IF NOT EXISTS vehicles (
        id SERIAL PRIMARY KEY,
        reg_no VARCHAR(30) UNIQUE NOT NULL,
        vehicle_type VARCHAR(50),
        capacity_kg NUMERIC(10, 2) CHECK (capacity_kg >= 0),
        status VARCHAR(15) NOT NULL DEFAULT 'active'
            CHECK (status IN ('active', 'maintenance', 'inactive'))
    );
    CREATE TABLE IF NOT EXISTS drivers (
        id SERIAL PRIMARY KEY,
        full_name VARCHAR(120) NOT NULL,
        phone VARCHAR(30),
        license_no VARCHAR(50) UNIQUE,
        vehicle_id INTEGER REFERENCES vehicles(id),
        is_active BOOLEAN NOT NULL DEFAULT TRUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS collections (
        id SERIAL PRIMARY KEY,
        collection_date DATE NOT NULL DEFAULT CURRENT_DATE,
        area_id INTEGER NOT NULL REFERENCES areas(id),
        vehicle_id INTEGER REFERENCES vehicles(id),
        driver_id INTEGER REFERENCES drivers(id),
        waste_type VARCHAR(20) NOT NULL CHECK (waste_type IN
            ('general', 'organic', 'recyclable', 'hazardous', 'e-waste', 'construction')),
        weight_kg NUMERIC(10, 2) NOT NULL DEFAULT 0 CHECK (weight_kg >= 0),
        status VARCHAR(15) NOT NULL DEFAULT 'collected'
            CHECK (status IN ('collected', 'pending', 'missed')),
        notes TEXT,
        created_by INTEGER REFERENCES users(id),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS complaints (
        id SERIAL PRIMARY KEY,
        complaint_date DATE NOT NULL DEFAULT CURRENT_DATE,
        area_id INTEGER NOT NULL REFERENCES areas(id),
        complainant VARCHAR(120),
        phone VARCHAR(30),
        description TEXT NOT NULL,
        status VARCHAR(15) NOT NULL DEFAULT 'open'
            CHECK (status IN ('open', 'in_progress', 'resolved')),
        assigned_to INTEGER REFERENCES users(id),
        resolved_at TIMESTAMP
    );
"""


def migrate_drivers_from_users(cur):
    """
    The first version stored drivers as login users (collections.driver_id -> users).
    If this database still has that layout, copy those drivers into the drivers table,
    repoint collections to them, and disable the old driver logins.
    """
    cur.execute("""
        SELECT con.conname, con.confrelid::regclass::text
        FROM pg_constraint con
        JOIN pg_attribute att ON att.attrelid = con.conrelid AND att.attnum = ANY(con.conkey)
        WHERE con.conrelid = 'collections'::regclass
          AND con.contype = 'f' AND att.attname = 'driver_id'
    """)
    row = cur.fetchone()
    if not row or row[1] != "users":
        return  # already on the new layout

    cur.execute(pgsql.SQL("ALTER TABLE collections DROP CONSTRAINT {}").format(pgsql.Identifier(row[0])))
    cur.execute("SELECT id, full_name, phone, is_active FROM users WHERE role = 'driver'")
    for old_id, name, phone, active in cur.fetchall():
        cur.execute("INSERT INTO drivers (full_name, phone, is_active) VALUES (%s, %s, %s) RETURNING id",
                    (name, phone, active))
        new_id = cur.fetchone()[0]
        # store as negative first so new ids can never clash with old ones
        cur.execute("UPDATE collections SET driver_id = %s WHERE driver_id = %s", (-new_id, old_id))
    cur.execute("UPDATE collections SET driver_id = NULL WHERE driver_id > 0")
    cur.execute("UPDATE collections SET driver_id = -driver_id WHERE driver_id < 0")
    cur.execute("ALTER TABLE collections ADD CONSTRAINT collections_driver_id_fkey "
                "FOREIGN KEY (driver_id) REFERENCES drivers(id)")
    cur.execute("UPDATE users SET is_active = FALSE WHERE role = 'driver'")


def init_db():
    """Create/upgrade tables. Returns True if the default admin account was just created."""
    conn = psycopg2.connect(**DB_CONFIG)
    try:
        with conn:
            with conn.cursor() as cur:
                cur.execute(SCHEMA_SQL)
                migrate_drivers_from_users(cur)
                cur.execute("SELECT COUNT(*) FROM users")
                if cur.fetchone()[0] == 0:
                    cur.execute(
                        "INSERT INTO users (username, password_hash, full_name, role) "
                        "VALUES (%s, %s, %s, 'admin')",
                        ("admin", hash_password("admin123"), "Administrator"),
                    )
                    return True
        return False
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Reusable form + table tab (add / update / delete / search)
# ---------------------------------------------------------------------------
class CrudTab(ttk.Frame):
    """
    fields: list of dicts with keys
        name, label, kind ('text' | 'decimal' | 'date' | 'choice' | 'fk' | 'bool' | 'password'),
        required (bool), values (for choice), default (for choice), sql (for fk: SELECT id, label)
    list_sql: query whose first column is id; may contain {where}
    """

    def __init__(self, parent, *, table, fields, list_sql, columns, where=("", ()),
                 fixed=None, insert_extra=None, can_delete=False, after_save_sql=None, protected_id=None):
        super().__init__(parent, padding=10)
        self.table = table
        self.fixed = fixed or {}
        self.fields = [f for f in fields if f["name"] not in self.fixed]
        self.insert_extra = insert_extra or {}
        self.list_sql = list_sql
        self.where = where
        self.after_save_sql = after_save_sql
        self.protected_id = protected_id
        self.selected_id = None
        self.widgets = {}
        self.fk_options = {}
        self.all_rows = []

        self.build_form(can_delete)
        self.build_table(columns)
        self.clear_form()
        self.refresh()

    # ----- UI -----
    def build_form(self, can_delete):
        form = ttk.LabelFrame(self, text="Details", padding=10)
        form.pack(fill="x")

        for i, f in enumerate(self.fields):
            row, col = divmod(i, 3)
            label = f["label"] + (" *" if f.get("required") else "")
            ttk.Label(form, text=label).grid(row=row, column=col * 2, sticky="w", padx=5, pady=4)

            kind = f["kind"]
            if kind == "bool":
                var = tk.BooleanVar(value=True)
                widget = ttk.Checkbutton(form, variable=var)
            elif kind in ("choice", "fk"):
                var = tk.StringVar()
                widget = ttk.Combobox(form, textvariable=var, state="readonly", width=23)
                if kind == "choice":
                    widget["values"] = f["values"]
            else:
                var = tk.StringVar()
                widget = ttk.Entry(form, textvariable=var, width=25, show="*" if kind == "password" else "")
            widget.grid(row=row, column=col * 2 + 1, sticky="w", padx=5, pady=4)
            self.widgets[f["name"]] = (f, var, widget)

        if any(f["kind"] == "password" for f in self.fields):
            ttk.Label(form, text="When updating, leave Password blank to keep the current one.",
                      foreground="#666").grid(row=99, column=0, columnspan=6, sticky="w", padx=5)

        bar = ttk.Frame(self)
        bar.pack(fill="x", pady=8)
        ttk.Button(bar, text="Add", command=lambda: self.save(updating=False)).pack(side="left", padx=4)
        ttk.Button(bar, text="Update", command=lambda: self.save(updating=True)).pack(side="left", padx=4)
        if can_delete:
            ttk.Button(bar, text="Delete", command=self.delete).pack(side="left", padx=4)
        ttk.Button(bar, text="Clear", command=self.clear_form).pack(side="left", padx=4)

        ttk.Button(bar, text="Refresh", command=self.refresh).pack(side="right", padx=4)
        self.search_var = tk.StringVar()
        search = ttk.Entry(bar, textvariable=self.search_var, width=25)
        search.pack(side="right", padx=4)
        search.bind("<KeyRelease>", lambda e: self.apply_filter())
        ttk.Label(bar, text="Search:").pack(side="right")

    def build_table(self, columns):
        frame = ttk.Frame(self)
        frame.pack(fill="both", expand=True)

        col_ids = [f"c{i}" for i in range(len(columns))]
        self.tree = ttk.Treeview(frame, columns=col_ids, show="headings")
        for cid, (heading, width) in zip(col_ids, columns):
            self.tree.heading(cid, text=heading)
            self.tree.column(cid, width=width, anchor="w")

        scroll = ttk.Scrollbar(frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll.set)
        self.tree.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        self.tree.bind("<<TreeviewSelect>>", self.on_select)

        self.count_label = ttk.Label(self, anchor="w")
        self.count_label.pack(fill="x", pady=(6, 0))

    # ----- Data loading -----
    def refresh(self):
        try:
            self.load_fk_options()
            where_sql, params = self.where
            self.all_rows = run_query(self.list_sql.format(where=where_sql), params, fetch="all")
        except psycopg2.Error as e:
            messagebox.showerror("Database Error", str(e))
            return
        self.apply_filter()

    def load_fk_options(self):
        for name, (f, var, widget) in self.widgets.items():
            if f["kind"] == "fk":
                options = list(run_query(f["sql"], fetch="all"))
                if not f.get("required"):
                    options = [(None, "")] + options
                self.fk_options[name] = options
                widget["values"] = [label for _, label in options]

    def apply_filter(self):
        term = self.search_var.get().strip().lower()
        self.tree.delete(*self.tree.get_children())
        shown = 0
        for row in self.all_rows:
            display = ["" if v is None else str(v) for v in row[1:]]
            if term and not any(term in d.lower() for d in display):
                continue
            self.tree.insert("", "end", iid=str(row[0]), values=display)
            shown += 1
        self.count_label.config(text=f"{shown} record(s)")

    def on_select(self, event=None):
        selected = self.tree.selection()
        if not selected:
            return
        record_id = int(selected[0])
        names = [f["name"] for f in self.fields if f["kind"] != "password"]
        try:
            row = run_query(f"SELECT {', '.join(names)} FROM {self.table} WHERE id = %s",
                            (record_id,), fetch="one")
        except psycopg2.Error as e:
            messagebox.showerror("Database Error", str(e))
            return
        if not row:
            return
        self.clear_form(keep_selection=True)
        self.selected_id = record_id
        for name, value in zip(names, row):
            self.set_value(name, value)

    def set_value(self, name, value):
        f, var, widget = self.widgets[name]
        kind = f["kind"]
        if kind == "bool":
            var.set(bool(value))
        elif kind == "fk":
            label = next((lbl for oid, lbl in self.fk_options.get(name, []) if oid == value), "")
            var.set(label)
        else:
            var.set("" if value is None else str(value))

    def clear_form(self, keep_selection=False):
        for name, (f, var, widget) in self.widgets.items():
            kind = f["kind"]
            if kind == "bool":
                var.set(True)
            elif kind == "date":
                var.set(datetime.date.today().isoformat())
            elif kind == "choice" and f.get("default"):
                var.set(f["default"])
            else:
                var.set("")
        self.selected_id = None
        if not keep_selection:
            self.tree.selection_remove(self.tree.selection())

    # ----- Saving -----
    def collect_data(self, updating):
        data = {}
        for name, (f, var, widget) in self.widgets.items():
            kind, label = f["kind"], f["label"]
            if kind == "bool":
                data[name] = var.get()
                continue

            raw = var.get().strip()
            if kind == "password":
                if not raw:
                    if updating:
                        continue
                    raise ValueError(f"{label} is required.")
                if len(raw) < 6:
                    raise ValueError("Password must be at least 6 characters.")
                data["password_hash"] = hash_password(raw)
                continue

            if not raw:
                if f.get("required"):
                    raise ValueError(f"{label} is required.")
                data[name] = None
                continue

            if kind == "fk":
                index = widget.current()
                data[name] = self.fk_options[name][index][0] if index >= 0 else None
                if data[name] is None and f.get("required"):
                    raise ValueError(f"{label} is required.")
            elif kind == "decimal":
                try:
                    value = Decimal(raw)
                except InvalidOperation:
                    raise ValueError(f"{label} must be a number.")
                if not value.is_finite() or value < 0:
                    raise ValueError(f"{label} must be a positive number.")
                data[name] = value
            elif kind == "date":
                try:
                    data[name] = datetime.date.fromisoformat(raw)
                except ValueError:
                    raise ValueError(f"{label} must be a date like 2026-09-25.")
            else:
                data[name] = raw

        data.update(self.fixed)
        return data

    def save(self, updating):
        if updating and self.selected_id is None:
            messagebox.showinfo("No selection", "Select a record in the table first.")
            return
        try:
            data = self.collect_data(updating)
        except ValueError as e:
            messagebox.showwarning("Check the form", str(e))
            return

        try:
            if updating:
                sets = ", ".join(f"{col} = %s" for col in data)
                run_query(f"UPDATE {self.table} SET {sets} WHERE id = %s",
                          list(data.values()) + [self.selected_id])
                record_id = self.selected_id
            else:
                data.update(self.insert_extra)
                cols = ", ".join(data)
                placeholders = ", ".join(["%s"] * len(data))
                record_id = run_query(
                    f"INSERT INTO {self.table} ({cols}) VALUES ({placeholders}) RETURNING id",
                    list(data.values()), fetch="one")[0]
            if self.after_save_sql:
                run_query(self.after_save_sql, (record_id,))
        except errors.UniqueViolation:
            messagebox.showerror("Duplicate", "A record with the same name / username / registration no. already exists.")
            return
        except psycopg2.Error as e:
            messagebox.showerror("Database Error", str(e))
            return

        self.clear_form()
        self.refresh()

    def delete(self):
        if self.selected_id is None:
            messagebox.showinfo("No selection", "Select a record in the table first.")
            return
        if self.protected_id is not None and self.selected_id == self.protected_id:
            messagebox.showwarning("Not allowed", "You cannot delete your own account.")
            return
        if not messagebox.askyesno("Confirm delete", "Delete the selected record?"):
            return
        try:
            run_query(f"DELETE FROM {self.table} WHERE id = %s", (self.selected_id,))
        except errors.ForeignKeyViolation:
            messagebox.showerror(
                "In use",
                "This record is used by other records (collections or complaints), so it can't be deleted.\n"
                "Mark it inactive instead.")
            return
        except psycopg2.Error as e:
            messagebox.showerror("Database Error", str(e))
            return
        self.clear_form()
        self.refresh()


# ---------------------------------------------------------------------------
# Dashboard
# ---------------------------------------------------------------------------
class DashboardTab(ttk.Frame):
    CARDS = ["Collections today", "Kg collected today", "Kg this month",
             "Missed this month", "Open complaints", "Active vehicles / drivers"]

    def __init__(self, parent):
        super().__init__(parent, padding=15)

        cards = ttk.Frame(self)
        cards.pack(fill="x")
        self.card_vars = {}
        for i, title in enumerate(self.CARDS):
            box = ttk.LabelFrame(cards, text=title, padding=10)
            box.grid(row=i // 3, column=i % 3, padx=8, pady=8, sticky="nsew")
            var = tk.StringVar(value="-")
            ttk.Label(box, textvariable=var, font=("Segoe UI", 20, "bold")).pack()
            self.card_vars[title] = var
        for c in range(3):
            cards.columnconfigure(c, weight=1)

        tables = ttk.Frame(self)
        tables.pack(fill="both", expand=True, pady=(10, 0))
        self.type_tree = self.make_table(tables, "This month by waste type",
                                         [("Waste type", 120), ("Trips", 60), ("Kg", 100)], 0)
        self.area_tree = self.make_table(tables, "Top areas this month",
                                         [("Area", 150), ("Trips", 60), ("Kg", 100)], 1)
        self.driver_tree = self.make_table(tables, "Top drivers this month",
                                           [("Driver", 150), ("Trips", 60), ("Kg", 100)], 2)
        for c in range(3):
            tables.columnconfigure(c, weight=1)

        ttk.Button(self, text="Refresh", command=self.refresh).pack(anchor="e", pady=10)
        self.refresh()

    @staticmethod
    def make_table(parent, title, columns, col):
        box = ttk.LabelFrame(parent, text=title, padding=8)
        box.grid(row=0, column=col, padx=8, sticky="nsew")
        ids = [f"c{i}" for i in range(len(columns))]
        tree = ttk.Treeview(box, columns=ids, show="headings", height=8)
        for cid, (heading, width) in zip(ids, columns):
            tree.heading(cid, text=heading)
            tree.column(cid, width=width, anchor="w")
        tree.pack(fill="both", expand=True)
        return tree

    def refresh(self):
        month = "c.collection_date >= date_trunc('month', CURRENT_DATE)"
        try:
            today = run_query(
                "SELECT COUNT(*), COALESCE(SUM(weight_kg), 0) FROM collections c "
                "WHERE c.collection_date = CURRENT_DATE AND c.status = 'collected'", fetch="one")
            this_month = run_query(
                "SELECT COALESCE(SUM(weight_kg) FILTER (WHERE status = 'collected'), 0), "
                f"COUNT(*) FILTER (WHERE status = 'missed') FROM collections c WHERE {month}",
                fetch="one")
            open_complaints = run_query(
                "SELECT COUNT(*) FROM complaints WHERE status <> 'resolved'", fetch="one")[0]
            active_vehicles = run_query(
                "SELECT COUNT(*) FROM vehicles WHERE status = 'active'", fetch="one")[0]
            active_drivers = run_query(
                "SELECT COUNT(*) FROM drivers WHERE is_active", fetch="one")[0]
            by_type = run_query(
                "SELECT waste_type, COUNT(*), COALESCE(SUM(weight_kg), 0) FROM collections c "
                f"WHERE c.status = 'collected' AND {month} "
                "GROUP BY waste_type ORDER BY 3 DESC", fetch="all")
            by_area = run_query(
                "SELECT a.name, COUNT(*), COALESCE(SUM(c.weight_kg), 0) FROM collections c "
                "JOIN areas a ON a.id = c.area_id "
                f"WHERE c.status = 'collected' AND {month} "
                "GROUP BY a.name ORDER BY 3 DESC LIMIT 10", fetch="all")
            by_driver = run_query(
                "SELECT d.full_name, COUNT(*), COALESCE(SUM(c.weight_kg), 0) FROM collections c "
                "JOIN drivers d ON d.id = c.driver_id "
                f"WHERE c.status = 'collected' AND {month} "
                "GROUP BY d.id, d.full_name ORDER BY 3 DESC LIMIT 10", fetch="all")
        except psycopg2.Error as e:
            messagebox.showerror("Database Error", str(e))
            return

        self.card_vars["Collections today"].set(str(today[0]))
        self.card_vars["Kg collected today"].set(f"{today[1]:,.1f}")
        self.card_vars["Kg this month"].set(f"{this_month[0]:,.1f}")
        self.card_vars["Missed this month"].set(str(this_month[1]))
        self.card_vars["Open complaints"].set(str(open_complaints))
        self.card_vars["Active vehicles / drivers"].set(f"{active_vehicles} / {active_drivers}")

        for tree, rows in ((self.type_tree, by_type), (self.area_tree, by_area),
                           (self.driver_tree, by_driver)):
            tree.delete(*tree.get_children())
            for name, trips, kg in rows:
                tree.insert("", "end", values=(name, trips, f"{kg:,.1f}"))


# ---------------------------------------------------------------------------
# Screens
# ---------------------------------------------------------------------------
class LoginFrame(ttk.Frame):
    def __init__(self, root, on_success, first_run):
        super().__init__(root, padding=30)
        self.on_success = on_success
        self.user_var = tk.StringVar()
        self.pass_var = tk.StringVar()
        self.logo = load_logo(LOGO_SIZE)

        ttk.Label(self, image=self.logo or "", compound="top", text="Waste Collection Management",
                  font=("Segoe UI", 16, "bold")).grid(row=0, column=0, columnspan=2, pady=(0, 20))
        ttk.Label(self, text="Username").grid(row=1, column=0, sticky="w", pady=5)
        user_entry = ttk.Entry(self, textvariable=self.user_var, width=28)
        user_entry.grid(row=1, column=1, pady=5)
        ttk.Label(self, text="Password").grid(row=2, column=0, sticky="w", pady=5)
        pass_entry = ttk.Entry(self, textvariable=self.pass_var, show="*", width=28)
        pass_entry.grid(row=2, column=1, pady=5)
        ttk.Button(self, text="Login", command=self.login).grid(row=3, column=0, columnspan=2,
                                                               sticky="ew", pady=15)
        if first_run:
            ttk.Label(self, text="First run: log in with admin / admin123, then change the password.",
                      foreground="#b35c00").grid(row=4, column=0, columnspan=2)

        pass_entry.bind("<Return>", lambda e: self.login())
        user_entry.focus()

    def login(self):
        username = self.user_var.get().strip()
        password = self.pass_var.get()
        try:
            row = run_query(
                "SELECT id, username, password_hash, full_name, role, is_active FROM users WHERE username = %s",
                (username,), fetch="one")
        except psycopg2.Error as e:
            messagebox.showerror("Database Error", str(e))
            return
        if not row or not verify_password(password, row[2]):
            messagebox.showerror("Login failed", "Wrong username or password.")
            return
        if not row[5] or row[4] not in ROLES:
            messagebox.showerror("Account disabled", "This account is inactive. Contact an admin.")
            return
        self.on_success({"id": row[0], "username": row[1], "full_name": row[3], "role": row[4]})


class MainScreen(ttk.Frame):
    def __init__(self, root, user, on_logout):
        super().__init__(root)
        self.user = user
        uid = user["id"]
        is_admin = user["role"] == "admin"

        top = ttk.Frame(self, padding=(10, 8))
        top.pack(fill="x")
        ttk.Label(top, text=f"Logged in as {user['full_name']} ({user['role']})",
                  font=("Segoe UI", 10, "bold")).pack(side="left")
        ttk.Button(top, text="Logout", command=on_logout).pack(side="right", padx=4)
        ttk.Button(top, text="Change Password", command=self.change_password).pack(side="right", padx=4)

        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill="both", expand=True, padx=10, pady=(0, 10))
        tabs = [("Dashboard", DashboardTab(self.notebook))]

        tabs.append(("Collections", CrudTab(
            self.notebook,
            table="collections",
            fields=[
                {"name": "collection_date", "label": "Date", "kind": "date", "required": True},
                {"name": "area_id", "label": "Area", "kind": "fk", "required": True,
                 "sql": "SELECT id, name FROM areas ORDER BY name"},
                {"name": "driver_id", "label": "Driver", "kind": "fk",
                 "sql": "SELECT id, full_name || CASE WHEN is_active THEN '' ELSE ' (inactive)' END "
                        "FROM drivers ORDER BY is_active DESC, full_name"},
                {"name": "vehicle_id", "label": "Vehicle", "kind": "fk",
                 "sql": "SELECT id, reg_no FROM vehicles ORDER BY reg_no"},
                {"name": "waste_type", "label": "Waste type", "kind": "choice", "required": True,
                 "values": WASTE_TYPES, "default": "general"},
                {"name": "weight_kg", "label": "Weight (kg)", "kind": "decimal", "required": True},
                {"name": "status", "label": "Status", "kind": "choice", "required": True,
                 "values": COLLECTION_STATUS, "default": "collected"},
                {"name": "notes", "label": "Notes", "kind": "text"},
            ],
            list_sql="""
                SELECT c.id, c.collection_date, a.name, d.full_name, v.reg_no,
                       c.waste_type, c.weight_kg, c.status, u.full_name, c.notes
                FROM collections c
                JOIN areas a ON a.id = c.area_id
                LEFT JOIN drivers d ON d.id = c.driver_id
                LEFT JOIN vehicles v ON v.id = c.vehicle_id
                LEFT JOIN users u ON u.id = c.created_by
                {where}
                ORDER BY c.collection_date DESC, c.id DESC
            """,
            columns=[("Date", 90), ("Area", 140), ("Driver", 140), ("Vehicle", 100),
                     ("Waste type", 100), ("Weight (kg)", 90), ("Status", 85),
                     ("Entered by", 120), ("Notes", 180)],
            insert_extra={"created_by": uid},
            can_delete=is_admin,
        )))

        tabs.append(("Complaints", CrudTab(
            self.notebook,
            table="complaints",
            fields=[
                {"name": "complaint_date", "label": "Date", "kind": "date", "required": True},
                {"name": "area_id", "label": "Area", "kind": "fk", "required": True,
                 "sql": "SELECT id, name FROM areas ORDER BY name"},
                {"name": "complainant", "label": "Complainant", "kind": "text"},
                {"name": "phone", "label": "Phone", "kind": "text"},
                {"name": "description", "label": "Problem", "kind": "text", "required": True},
                {"name": "status", "label": "Status", "kind": "choice", "required": True,
                 "values": COMPLAINT_STATUS, "default": "open"},
                {"name": "assigned_to", "label": "Assigned to", "kind": "fk",
                 "sql": "SELECT id, full_name FROM users WHERE role IN ('admin', 'staff') "
                        "ORDER BY full_name"},
            ],
            list_sql="""
                SELECT cp.id, cp.complaint_date, a.name, cp.complainant, cp.phone,
                       cp.description, cp.status, u.full_name, cp.resolved_at
                FROM complaints cp
                JOIN areas a ON a.id = cp.area_id
                LEFT JOIN users u ON u.id = cp.assigned_to
                {where}
                ORDER BY cp.status = 'resolved', cp.complaint_date DESC, cp.id DESC
            """,
            columns=[("Date", 90), ("Area", 130), ("Complainant", 120), ("Phone", 100),
                     ("Problem", 240), ("Status", 90), ("Assigned to", 120), ("Resolved at", 130)],
            can_delete=is_admin,
            after_save_sql="""
                UPDATE complaints SET resolved_at = CASE WHEN status = 'resolved'
                    THEN COALESCE(resolved_at, CURRENT_TIMESTAMP) ELSE NULL END
                WHERE id = %s
            """,
        )))

        tabs.append(("Drivers", CrudTab(
            self.notebook,
            table="drivers",
            fields=[
                {"name": "full_name", "label": "Full name", "kind": "text", "required": True},
                {"name": "phone", "label": "Phone", "kind": "text"},
                {"name": "license_no", "label": "License no.", "kind": "text"},
                {"name": "vehicle_id", "label": "Usual vehicle", "kind": "fk",
                 "sql": "SELECT id, reg_no FROM vehicles ORDER BY reg_no"},
                {"name": "is_active", "label": "Active", "kind": "bool"},
            ],
            list_sql="""
                SELECT d.id, d.full_name, d.phone, d.license_no, v.reg_no,
                       CASE WHEN d.is_active THEN 'Yes' ELSE 'No' END
                FROM drivers d
                LEFT JOIN vehicles v ON v.id = d.vehicle_id
                {where}
                ORDER BY d.is_active DESC, d.full_name
            """,
            columns=[("Full name", 200), ("Phone", 130), ("License no.", 140),
                     ("Usual vehicle", 120), ("Active", 70)],
            can_delete=is_admin,
        )))

        tabs.append(("Areas", CrudTab(
            self.notebook,
            table="areas",
            fields=[
                {"name": "name", "label": "Area name", "kind": "text", "required": True},
                {"name": "ward", "label": "Ward", "kind": "text"},
                {"name": "description", "label": "Description", "kind": "text"},
            ],
            list_sql="SELECT id, name, ward, description FROM areas {where} ORDER BY name",
            columns=[("Area name", 200), ("Ward", 100), ("Description", 400)],
            can_delete=is_admin,
        )))

        tabs.append(("Vehicles", CrudTab(
            self.notebook,
            table="vehicles",
            fields=[
                {"name": "reg_no", "label": "Reg. No", "kind": "text", "required": True},
                {"name": "vehicle_type", "label": "Type", "kind": "text"},
                {"name": "capacity_kg", "label": "Capacity (kg)", "kind": "decimal"},
                {"name": "status", "label": "Status", "kind": "choice", "required": True,
                 "values": VEHICLE_STATUS, "default": "active"},
            ],
            list_sql="SELECT id, reg_no, vehicle_type, capacity_kg, status FROM vehicles {where} ORDER BY reg_no",
            columns=[("Reg. No", 140), ("Type", 150), ("Capacity (kg)", 120), ("Status", 110)],
            can_delete=is_admin,
        )))

        if is_admin:
            tabs.append(("Users", CrudTab(
                self.notebook,
                table="users",
                fields=[
                    {"name": "username", "label": "Username", "kind": "text", "required": True},
                    {"name": "full_name", "label": "Full name", "kind": "text", "required": True},
                    {"name": "phone", "label": "Phone", "kind": "text"},
                    {"name": "role", "label": "Role", "kind": "choice", "required": True,
                     "values": ROLES, "default": "staff"},
                    {"name": "is_active", "label": "Active", "kind": "bool"},
                    {"name": "password", "label": "Password", "kind": "password", "required": True},
                ],
                list_sql="""
                    SELECT id, username, full_name, phone, role,
                           CASE WHEN is_active THEN 'Yes' ELSE 'No' END
                    FROM users WHERE role IN ('admin', 'staff') ORDER BY role, full_name
                """,
                columns=[("Username", 130), ("Full name", 180), ("Phone", 120), ("Role", 90), ("Active", 70)],
                can_delete=True,
                protected_id=uid,
            )))

        for title, tab in tabs:
            self.notebook.add(tab, text=title)
        self.notebook.bind("<<NotebookTabChanged>>", self.on_tab_changed)

    def on_tab_changed(self, event=None):
        tab = self.notebook.nametowidget(self.notebook.select())
        tab.refresh()

    def change_password(self):
        win = tk.Toplevel(self)
        win.title("Change Password")
        win.resizable(False, False)
        win.transient(self.winfo_toplevel())
        win.grab_set()

        labels = ["Current password", "New password", "Confirm new password"]
        variables = [tk.StringVar() for _ in labels]
        for i, (label, var) in enumerate(zip(labels, variables)):
            ttk.Label(win, text=label).grid(row=i, column=0, sticky="w", padx=10, pady=5)
            ttk.Entry(win, textvariable=var, show="*", width=25).grid(row=i, column=1, padx=10, pady=5)

        def submit():
            current, new, confirm = (v.get() for v in variables)
            try:
                row = run_query("SELECT password_hash FROM users WHERE id = %s",
                                (self.user["id"],), fetch="one")
                if not row or not verify_password(current, row[0]):
                    messagebox.showwarning("Wrong password", "Current password is incorrect.", parent=win)
                    return
                if len(new) < 6:
                    messagebox.showwarning("Too short", "New password must be at least 6 characters.", parent=win)
                    return
                if new != confirm:
                    messagebox.showwarning("Mismatch", "New passwords do not match.", parent=win)
                    return
                run_query("UPDATE users SET password_hash = %s WHERE id = %s",
                          (hash_password(new), self.user["id"]))
            except psycopg2.Error as e:
                messagebox.showerror("Database Error", str(e), parent=win)
                return
            messagebox.showinfo("Done", "Password changed.", parent=win)
            win.destroy()

        ttk.Button(win, text="Save", command=submit).grid(row=3, column=0, columnspan=2, pady=10)


class WasteApp:
    def __init__(self, root, first_run):
        self.root = root
        self.root.title("Waste Collection Management")
        self.root.geometry("1150x700")
        self.icon = load_logo(64)
        if self.icon:
            self.root.iconphoto(True, self.icon)
        self.first_run = first_run
        self.current = None
        self.show_login()

    def clear(self):
        if self.current is not None:
            self.current.destroy()

    def show_login(self):
        self.clear()
        screen = tk.Frame(self.root)
        screen.pack(fill="both", expand=True)
        screen.background = BackgroundImage(screen)
        form = LoginFrame(screen, self.on_login, self.first_run)
        form.place(relx=0.5, rely=0.5, anchor="center")
        self.current = screen
        

    def on_login(self, user):
        self.first_run = False
        self.clear()
        self.current = MainScreen(self.root, user, self.show_login)
        self.current.pack(fill="both", expand=True)


def main():
    root = tk.Tk()
    try:
        ensure_database()
    except psycopg2.Error:
        pass  # no permission to create databases; init_db below will report real problems
    try:
        first_run = init_db()
    except psycopg2.Error as e:
        messagebox.showerror("Cannot connect to database",
                             f"{e}\n\nCheck DB_CONFIG at the top of waste_management.py.")
        root.destroy()
        return
    WasteApp(root, first_run)
    root.mainloop()


if __name__ == "__main__":
    main()
