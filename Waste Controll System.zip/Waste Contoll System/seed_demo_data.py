"""
Demo data for the Waste Collection Management app.

Put this file in the same folder as waste_management.py, then run:
    py seed_demo_data.py          -> add demo data
    py seed_demo_data.py --reset  -> DELETE all areas, vehicles, drivers, collections,
                                     complaints and demo staff, then add fresh demo data

Demo staff logins created:  rahim / staff123   and   nasrin / staff123
"""
import datetime
import random
import sys

import psycopg2
from psycopg2.extras import execute_values

from waste_management import DB_CONFIG, ensure_database, hash_password, init_db

random.seed(42)
TODAY = datetime.date.today()
DAYS = 60

AREAS = [
    ("Mirpur-10", "Ward 2", "Dense residential area with a large kitchen market"),
    ("Uttara Sector 7", "Ward 1", "Residential sector near the main road"),
    ("Dhanmondi", "Ward 15", "Residential and commercial area"),
    ("Gulshan-1", "Ward 19", "Commercial area with offices and restaurants"),
    ("Banani", "Ward 19", "Mixed residential and commercial"),
    ("Mohammadpur", "Ward 29", "Residential area with Town Hall market"),
    ("Motijheel", "Ward 9", "Central business district"),
    ("Badda", "Ward 21", "Growing residential area"),
    ("Farmgate", "Ward 27", "Busy transport hub and shops"),
    ("Bashundhara", "Ward 17", "Residential area with a large shopping mall"),
]

# reg_no, type, capacity_kg, status
VEHICLES = [
    ("DM-TA-11-2345", "Compactor truck", 5000, "active"),
    ("DM-TA-11-2346", "Compactor truck", 5000, "active"),
    ("DM-TA-14-7781", "Open truck", 3000, "active"),
    ("DM-TA-14-7782", "Open truck", 3000, "active"),
    ("DM-NA-13-4410", "Pickup van", 1500, "active"),
    ("DM-NA-13-4411", "Pickup van", 1500, "active"),
    ("DM-TA-18-0932", "Container carrier", 7000, "maintenance"),
    ("DM-TA-09-5520", "Open truck", 3000, "inactive"),
]

# full_name, phone, license_no, usual vehicle index (into VEHICLES), active
DRIVERS = [
    ("Abdul Karim", "01711-000101", "DK-0452183", 0, True),
    ("Jamal Hossain", "01711-000102", "DK-0452184", 1, True),
    ("Rafiqul Islam", "01811-000103", "DK-0452185", 2, True),
    ("Shahidul Alam", "01811-000104", "DK-0452186", 3, True),
    ("Monir Hossain", "01911-000105", "DK-0452187", 4, True),
    ("Babul Mia", "01911-000106", "DK-0452188", 5, True),
    ("Harun Rashid", "01611-000107", "DK-0452189", 6, True),
    ("Selim Reza", "01611-000108", "DK-0452190", None, True),
    ("Kamal Uddin", "01511-000109", "DK-0452191", 7, False),
]

STAFF = [
    ("rahim", "Rahim Uddin", "01700-111222", "staff"),
    ("nasrin", "Nasrin Akter", "01700-333444", "staff"),
]
STAFF_PASSWORD = "staff123"

WASTE_WEIGHTS = {
    "general": 45, "organic": 30, "recyclable": 12,
    "construction": 7, "hazardous": 3, "e-waste": 3,
}
MISSED_REASONS = ["Road blocked by construction", "Vehicle breakdown", "Driver absent",
                  "Heavy rain, road flooded", "Bin access blocked by parked cars"]
COLLECTED_NOTES = ["", "", "", "", "Bin overflowing on arrival", "Extra load from market",
                   "Mixed waste, not separated", "Collected late due to traffic"]

COMPLAINTS = [
    "Garbage not collected for 3 days",
    "Overflowing bin near the market",
    "Bad smell from the dumping point",
    "Waste thrown on the roadside",
    "Collection truck spilled waste on the road",
    "Bin is broken and needs replacement",
    "Collection time is too early, residents miss it",
    "Medical waste found in household bin",
    "Stray dogs scattering garbage",
    "Drain blocked with plastic waste",
    "Construction debris dumped on footpath",
    "Request for an extra bin in the lane",
]
COMPLAINANTS = ["Mizanur Rahman", "Farzana Haque", "Tanvir Ahmed", "Sabina Yasmin",
                "Arif Hasan", "Ruma Begum", "Shafiq Chowdhury", "Nusrat Jahan",
                "Imran Kabir", "Laila Sultana", "", ""]


def confirm(question):
    return input(f"{question} (y/n): ").strip().lower() in ("y", "yes")


def reset(cur):
    cur.execute("TRUNCATE collections, complaints, drivers, vehicles, areas RESTART IDENTITY CASCADE")
    cur.execute("DELETE FROM users WHERE username = ANY(%s)", ([s[0] for s in STAFF],))


def seed(cur):
    # ---- Areas ----
    execute_values(cur, "INSERT INTO areas (name, ward, description) VALUES %s "
                        "ON CONFLICT (name) DO NOTHING", AREAS)
    cur.execute("SELECT id FROM areas WHERE name = ANY(%s) ORDER BY id", ([a[0] for a in AREAS],))
    area_ids = [r[0] for r in cur.fetchall()]

    # ---- Vehicles ----
    execute_values(cur, "INSERT INTO vehicles (reg_no, vehicle_type, capacity_kg, status) VALUES %s "
                        "ON CONFLICT (reg_no) DO NOTHING", VEHICLES)
    vehicle_ids, capacity = [], {}
    for reg_no, _, cap, _ in VEHICLES:
        cur.execute("SELECT id FROM vehicles WHERE reg_no = %s", (reg_no,))
        vid = cur.fetchone()[0]
        vehicle_ids.append(vid)
        capacity[vid] = cap

    # ---- Drivers ----
    driver_rows = []  # (driver_id, vehicle_id, active)
    for name, phone, license_no, v_index, active in DRIVERS:
        vid = vehicle_ids[v_index] if v_index is not None else None
        cur.execute(
            "INSERT INTO drivers (full_name, phone, license_no, vehicle_id, is_active) "
            "VALUES (%s, %s, %s, %s, %s) ON CONFLICT (license_no) DO NOTHING",
            (name, phone, license_no, vid, active))
        cur.execute("SELECT id FROM drivers WHERE license_no = %s", (license_no,))
        driver_rows.append((cur.fetchone()[0], vid, active))

    # ---- Staff users ----
    for username, full_name, phone, role in STAFF:
        cur.execute(
            "INSERT INTO users (username, password_hash, full_name, phone, role) "
            "VALUES (%s, %s, %s, %s, %s) ON CONFLICT (username) DO NOTHING",
            (username, hash_password(STAFF_PASSWORD), full_name, phone, role))
    cur.execute("SELECT id FROM users WHERE is_active AND role IN ('admin', 'staff')")
    user_ids = [r[0] for r in cur.fetchall()]

    # ---- Collections: last 60 days ----
    working = [(d, v, capacity[v]) for d, v, active in driver_rows
               if active and v is not None and VEHICLES[vehicle_ids.index(v)][3] == "active"]
    spare_driver = next(d for d, v, active in driver_rows if active and v is None)
    waste_types = list(WASTE_WEIGHTS)
    weights = list(WASTE_WEIGHTS.values())

    collections = []
    for offset in range(DAYS, -1, -1):
        day = TODAY - datetime.timedelta(days=offset)
        is_friday = day.weekday() == 4
        for driver_id, vehicle_id, cap in working:
            if is_friday and random.random() < 0.6:
                continue  # lighter schedule on Fridays
            if random.random() < 0.05:
                driver_id = spare_driver  # usual driver on leave, spare driver covers
            for _ in range(random.choice([1, 1, 2])):
                waste = random.choices(waste_types, weights)[0]
                roll = random.random()
                if offset == 0 and roll < 0.3:
                    status, kg, note = "pending", 0, "Scheduled for this afternoon"
                elif roll < 0.06:
                    status, kg, note = "missed", 0, random.choice(MISSED_REASONS)
                else:
                    status = "collected"
                    kg = round(cap * random.uniform(0.45, 0.95), 2)
                    if waste in ("hazardous", "e-waste"):
                        kg = round(kg * 0.1, 2)  # these come in small loads
                    note = random.choice(COLLECTED_NOTES)
                collections.append((day, random.choice(area_ids), vehicle_id, driver_id, waste,
                                    kg, status, note or None, random.choice(user_ids)))

    execute_values(cur, """
        INSERT INTO collections (collection_date, area_id, vehicle_id, driver_id, waste_type,
                                 weight_kg, status, notes, created_by)
        VALUES %s""", collections)

    # ---- Complaints ----
    staff_ids = user_ids
    complaints = []
    for _ in range(30):
        offset = random.randint(0, DAYS)
        day = TODAY - datetime.timedelta(days=offset)
        if offset > 10:
            status = random.choices(["resolved", "in_progress", "open"], [85, 10, 5])[0]
        else:
            status = random.choices(["open", "in_progress", "resolved"], [45, 30, 25])[0]
        resolved_at = None
        if status == "resolved":
            resolved_at = datetime.datetime.combine(
                day + datetime.timedelta(days=random.randint(0, min(3, offset))),
                datetime.time(random.randint(9, 17), random.choice([0, 15, 30, 45])))
        assigned = random.choice(staff_ids) if status != "open" or random.random() < 0.5 else None
        name = random.choice(COMPLAINANTS)
        phone = f"017{random.randint(10000000, 99999999)}" if name else None
        complaints.append((day, random.choice(area_ids), name or None, phone,
                           random.choice(COMPLAINTS), status, assigned, resolved_at))

    execute_values(cur, """
        INSERT INTO complaints (complaint_date, area_id, complainant, phone, description,
                                status, assigned_to, resolved_at)
        VALUES %s""", complaints)

    return len(collections), len(complaints)


def main():
    do_reset = "--reset" in sys.argv
    ensure_database()
    init_db()

    conn = psycopg2.connect(**DB_CONFIG)
    try:
        with conn:
            with conn.cursor() as cur:
                if do_reset:
                    if not confirm("This DELETES all areas, vehicles, drivers, collections and "
                                   "complaints (user logins are kept). Continue?"):
                        print("Cancelled.")
                        return
                    reset(cur)
                else:
                    cur.execute("SELECT COUNT(*) FROM collections")
                    if cur.fetchone()[0] > 0 and not confirm(
                            "The database already has collections. Add demo data on top?"):
                        print("Cancelled. Use --reset to start fresh.")
                        return
                n_collections, n_complaints = seed(cur)
    finally:
        conn.close()

    print("Demo data added:")
    print(f"  {len(AREAS)} areas, {len(VEHICLES)} vehicles, {len(DRIVERS)} drivers")
    print(f"  {n_collections} collections over the last {DAYS} days")
    print(f"  {n_complaints} complaints")
    print(f"  Staff logins: rahim / {STAFF_PASSWORD}, nasrin / {STAFF_PASSWORD}")


if __name__ == "__main__":
    main()
